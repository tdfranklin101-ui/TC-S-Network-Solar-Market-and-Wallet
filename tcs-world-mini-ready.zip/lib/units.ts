export const ONE_SOLAR_KWH = 4913; // 1 Solar = 4,913 kWh
export const RAYS_PER_SOLAR = 10000; // 1 Solar = 10,000 Rays (basis points-style)

export function kWhToSolar(kwh: number): number {
  return kwh / ONE_SOLAR_KWH;
}
export function solarToRays(solar: number): number {
  return Math.round(solar * RAYS_PER_SOLAR);
}
export function kWhToRays(kwh: number): number {
  return solarToRays(kWhToSolar(kwh));
}
export function fmtSolar(solar: number): string {
  return solar.toFixed(4);
}
