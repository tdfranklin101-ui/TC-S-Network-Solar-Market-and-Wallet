import { NextResponse } from 'next/server';
import { supabaseService } from '@/lib/supabase-server';

export const runtime = 'nodejs';

export async function GET() {
  try {
    const sb = supabaseService();
    const { data, error } = await sb
      .from('tcs_items')
      .select('id,title,description,rays_price')
      .order('created_at', { ascending: false })
      .limit(24);
    if (error) throw error;
    return NextResponse.json(data ?? []);
  } catch (e: any) {
    console.error('market/list error', e?.message || e);
    // Return empty list in submission context to avoid hard failures.
    return NextResponse.json([], { status: 200 });
  }
}
