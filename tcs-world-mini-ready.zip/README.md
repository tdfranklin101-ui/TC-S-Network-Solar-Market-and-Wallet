# TC‑S World Mini (Submission Package)

A self-contained Next.js mini-app for World.org.

## What’s inside
- **App Router** with `Identify`, `Market`, `Wallet` pages
- **API routes** for market list, item detail, wallet balance/daily/transfer, plus idempotent **/api/seed**
- **Tailwind CSS** for clean UI
- **Supabase** server utility (uses `SUPABASE_URL` + `SUPABASE_SERVICE_KEY` at runtime)

## Deploy (World.org or Vercel)
1) Upload this zip as-is. No edits needed.
2) Add Environment Variables:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_KEY`
   - (optional) `OPENAI_API_KEY`
3) Open the deployed app → visit `/api/seed` once to bootstrap demo tables/data (safe to re-run).
4) Use `/identify`, `/market`, `/wallet`.

## Notes
- Pages are **dynamic** and do not pre-fetch during build to avoid SSR build-time API calls.
- If env isn’t present, APIs return safe fallbacks so the app still renders for submission.
