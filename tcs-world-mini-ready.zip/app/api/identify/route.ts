import { NextResponse } from 'next/server';
import { kWhToRays, kWhToSolar } from '@/lib/units';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const { desc } = await req.json().catch(() => ({ desc: '' }));
  // Minimal placeholder estimator for submission: length-based heuristic.
  const words = (desc || '').trim().split(/\s+/).filter(Boolean).length;
  const kwh = Math.max(0.1, Math.min(25, words * 0.05));
  const solar = kWhToSolar(kwh);
  const rays = kWhToRays(kwh);
  return NextResponse.json({ desc, estimate: { kwh, solar, rays } });
}
