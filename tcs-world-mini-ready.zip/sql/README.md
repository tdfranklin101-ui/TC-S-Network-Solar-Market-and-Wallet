# TC‑S World Mini • SQL helpers

Optional Postgres helpers you can create in your Supabase project:

```sql
-- Increment balance safely
create or replace function tcs_increment_balance(p_wallet_id uuid, p_kwh numeric)
returns void language plpgsql as $$
begin
  insert into tcs_balances(wallet_id, kwh) values (p_wallet_id, p_kwh)
  on conflict (wallet_id) do update set kwh = tcs_balances.kwh + excluded.kwh;
end; $$;

-- Transfer between wallets atomically
create or replace function tcs_transfer(p_from uuid, p_to uuid, p_kwh numeric)
returns void language plpgsql as $$
begin
  update tcs_balances set kwh = kwh - p_kwh where wallet_id = p_from;
  insert into tcs_balances(wallet_id, kwh) values (p_to, p_kwh)
  on conflict (wallet_id) do update set kwh = tcs_balances.kwh + excluded.kwh;
end; $$;

-- Execute arbitrary SQL (locked down in prod; here for guided seed only)
create or replace function tcs_exec_sql(p_sql text)
returns void language plpgsql as $$
begin
  execute p_sql;
end; $$;
```
