/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    esmExternals: true,
  },
  typescript: {
    // Don't block build on type errors in deployment environments
    ignoreBuildErrors: true,
  },
};
module.exports = nextConfig;
